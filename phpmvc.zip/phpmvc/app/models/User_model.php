<?php 

class User_model {
    private $nama = 'putri selvita sari';

    public function getUser()
    {
        return $this->nama;
    }
}